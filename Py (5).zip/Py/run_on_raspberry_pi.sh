#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
VENV_DIR="$PROJECT_DIR/.venv"
REQ_FILE="$PROJECT_DIR/requirements.txt"

install_system_packages() {
  if command -v sudo >/dev/null 2>&1; then
    sudo apt update
    sudo apt install -y ffmpeg libsdl2-2.0-0 libsdl2-image-2.0-0 libsdl2-mixer-2.0-0 libsdl2-ttf-2.0-0 python3-venv
  else
    apt update
    apt install -y ffmpeg libsdl2-2.0-0 libsdl2-image-2.0-0 libsdl2-mixer-2.0-0 libsdl2-ttf-2.0-0 python3-venv
  fi
}

echo "[1/6] Checking Python..."
if ! command -v python3 >/dev/null 2>&1; then
  echo "python3 is not installed. Install Raspberry Pi OS Python packages first."
  exit 1
fi

echo "[2/6] Installing system packages (if needed)..."
if ! command -v ffplay >/dev/null 2>&1; then
  install_system_packages
fi

echo "[3/6] Creating virtual environment..."
if [ ! -d "$VENV_DIR" ]; then
  if ! python3 -m venv "$VENV_DIR"; then
    echo "python3-venv missing, installing required packages..."
    install_system_packages
    python3 -m venv "$VENV_DIR"
  fi
fi

echo "[4/6] Installing Python dependencies..."
source "$VENV_DIR/bin/activate"
python -m pip install --upgrade pip
pip install -r "$REQ_FILE"

echo "[5/6] Preparing project folders..."
mkdir -p "$PROJECT_DIR/photos" "$PROJECT_DIR/videos"
if [ ! -f "$PROJECT_DIR/config.json" ]; then
  printf '{"photo_interval": 5}\n' > "$PROJECT_DIR/config.json"
fi
if [ ! -f "$PROJECT_DIR/pending_delete.json" ]; then
  printf '[]\n' > "$PROJECT_DIR/pending_delete.json"
fi

echo "[6/6] Starting Media Controller..."
echo "Open this in browser: http://<raspberry-pi-ip>:5000"
exec python "$PROJECT_DIR/app.py"
