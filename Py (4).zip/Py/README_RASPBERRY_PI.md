﻿# Raspberry Pi Quick Run

Friend only needs to do this after receiving the folder:

```bash
cd /path/to/this-folder
bash run_on_raspberry_pi.sh
```

What this script does automatically:
- installs required system packages (`ffmpeg`, SDL, `python3-venv`) if missing
- creates `.venv`
- installs Python dependencies from `requirements.txt`
- creates `photos/`, `videos/`, `config.json`, `pending_delete.json` if missing
- starts `app.py`

Then open:

```text
http://<raspberry-pi-ip>:5000
```

From the web UI, press `START` to run slideshow.
